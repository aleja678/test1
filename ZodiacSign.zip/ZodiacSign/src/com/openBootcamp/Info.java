package com.openBootcamp;

import java.util.Scanner;

public class Info {

    static String nombre;
    static int mes;
    static int dia;


    public static void getName(){
        System.out.print("Ingresa tu nombre:");

        Scanner scanNombre = new Scanner(System.in);
        nombre = scanNombre.next();
    }

    public static int getDay() throws NumberFormatException {

        System.out.print("Ingresa tu dia de nacimiento:");

        Scanner scanDia = new Scanner(System.in);
        try {
            dia = Integer.valueOf(scanDia.next());
        } catch (NumberFormatException e) {
            throw new NumberFormatException();
        } return dia;
    }

    public static int getMonth() throws NumberFormatException {

        System.out.print("Ingresa el numero de tu mes de nacimiento:");

        Scanner scanMes = new Scanner(System.in);
        try{
            mes = Integer.valueOf(scanMes.next());
        } catch (NumberFormatException e) {
            throw new NumberFormatException();
        } return mes;
    }

    public static  String getSign(int dia, int mes) {

        if (mes == 1) {
            for (int i = 0; i < capricornioArray[1].length; i++) {
                if (capricornioArray[1][i] == dia) {
                    return "Eres capricornio";
                }
            } for (int j = 0; j < acuarioArray[0].length; j++) {
                if (acuarioArray[0][j]== dia) {
                    return "Eres acuario";
                }
            }
        } else if (mes == 2){
            for (int i = 0; i < acuarioArray[1].length; i++){
                if (acuarioArray[1][i] == dia) {
                    return "Eres acuario";
                }
            } for (int j = 0; j < piscisArray[0].length; j++){
                if (piscisArray[0][j] == dia) {
                    return "Eres piscis";
                }
            }
        } else if (mes == 3) {
            for (int i = 0; i < piscisArray[1].length; i++) {
                if (piscisArray[1][i] == dia) {
                    return "Eres piscis";
                }
            } for (int j = 0; j < ariesArray[0].length; j++){
                if (ariesArray[0][j] == dia) {
                    return "Eres aries";
                }
            }
        } else if (mes == 4) {
            for (int i = 0; i < ariesArray[1].length; i++) {
                if (ariesArray[1][i] == dia) {
                    return "Eres aries";
                }
            } for (int j = 0; j < tauroArray[0].length; j++){
                if (tauroArray[0][j] == dia) {
                    return "Eres tauro";
                }
            }
        } else if (mes == 5) {
            for (int i = 0; i < tauroArray[1].length; i++) {
                if (tauroArray[1][i] == dia) {
                    return "Eres tauro";
                }
            } for (int j = 0; j < geminisArray[0].length; j++){
                if (geminisArray[0][j] == dia) {
                    return "Eres geminis";
                }
            }
        } else if (mes == 6) {
            for (int i = 0; i < geminisArray[1].length; i++) {
                if (geminisArray[1][i] == dia) {
                    return "Eres geminis";
                }
            } for (int j = 0; j < cancerArray[0].length; j++){
                if (cancerArray[0][j] == dia) {
                    return "Eres cancer";
                }
            }
        } else if (mes == 7) {
            for (int i = 0; i < cancerArray[1].length; i++) {
                if (cancerArray[1][i] == dia) {
                    return "Eres cancer";
                }
            } for (int j = 0; j < leoArray[0].length; j++){
                if (leoArray[0][j] == dia) {
                    return "Eres leo";
                }
            }
        } else if (mes == 8) {
            for (int i = 0; i < leoArray[1].length; i++) {
                if (leoArray[1][i] == dia) {
                    return "Eres leo";
                }
            } for (int j = 0; j < virgoArray[0].length; j++){
                if (virgoArray[0][j] == dia) {
                    return "Eres virgo";
                }
            }
        } else if (mes == 9) {
            for (int i = 0; i < virgoArray[1].length; i++) {
                if (virgoArray[1][i] == dia) {
                    return "Eres virgo";}
            } for (int j = 0; j < libraArray[0].length; j++){
                if (libraArray[0][j] == dia) {
                    return "Eres libra";
                }
            }
        } else if (mes == 10) {
            for (int i = 0; i < libraArray[1].length; i++) {
                if (libraArray[1][i] == dia) {
                    return "Eres libra";
                }
            } for (int j = 0; j < escorpioArray[0].length; j++){
                if (escorpioArray[0][j] == dia) {
                    return "Eres escorpio";
                }
            }
        } else if (mes == 11) {
            for (int i = 0; i < escorpioArray[1].length; i++) {
                if (escorpioArray[1][i] == dia) {
                    return "Eres escorpio";
                }
            } for (int j = 0; j < sagitarioArray[0].length; j++){
                if (sagitarioArray[0][j] == dia) {
                    return "Eres sagitario";
                }
            }
        } else if (mes == 12) {
            for (int i = 0; i < sagitarioArray[1].length; i++) {
                if (sagitarioArray[1][i] == dia) {
                    return "Eres sagitario";
                }
            } for (int j = 0; j < capricornioArray[0].length; j++){
                if (capricornioArray[0][j] == dia) {
                    return "Eres capricornio";
                }
            }
        } return "no se encontro tu signo";
    }

    static int[][] piscisArray = {
            {21, 22, 23, 24, 25, 26, 27, 28, 29},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
    };
    static int[][] ariesArray = {
            {21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18},
    };

    static int[][] tauroArray = {
            {19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
    };

    static int[][] geminisArray = {
            {21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
    };

    static int[][] cancerArray = {
            {21, 22, 23, 24, 25, 26, 27, 28, 29, 30},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22},
    };

    static int[][] leoArray = {
            {23, 24, 25, 26, 27, 28, 29, 30, 31},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23},
    };

    static int[][] virgoArray = {
            {24, 25, 26, 27, 28, 29, 30, 31},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22},
    };

    static int[][] libraArray = {
            {23, 24, 25, 26, 27, 28, 29, 30},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22},
    };

    static int[][] escorpioArray = {
            {23, 24, 25, 26, 27, 28, 29, 30, 31},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21},
    };

    static int[][] acuarioArray = {
            {21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
    };
    static int[][] sagitarioArray = {
            {22, 23, 24, 25, 26, 27, 28, 29, 30, 31},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21},
    };

    static int[][] capricornioArray = {
            {22, 23, 24, 25, 26, 27, 28, 29, 30, 31},
            {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19},
    };

}












