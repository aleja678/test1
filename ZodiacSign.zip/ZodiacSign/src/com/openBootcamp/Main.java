package com.openBootcamp;
import java.util.HashMap;
import static com.openBootcamp.Info.*;


public class Main {

    public static void main(String[] args) {

        getName();
        try{
            getDay();
        } catch (NumberFormatException e){
            System.out.println("Debes ingresar un numero entre 1 y 30");
        }

        try{
        getMonth();
        } catch (NumberFormatException e){
            System.out.println("Debes ingresar un numero entre 1 y 12");
        }



        String signo = getSign(dia,mes);
        System.out.println(signo);


        HashMap<String,String> dataBase = new HashMap<>();
        dataBase.put(nombre,signo);
        System.out.println(dataBase.size());

    }


}








