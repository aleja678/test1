package com.openBootcamp;

public class DividePorCero {

    public static void main(String[] args) {
        dividePorCero(4,1);

    }

    public static void dividePorCero (int A, int B){
        try {int resultado = A/B;
            System.out.println(resultado);
        } catch (ArithmeticException e) {
            System.out.println("Esto no puede hacerse");
        } finally {
            System.out.println("Codigo Demo");
        } 
    }
}
