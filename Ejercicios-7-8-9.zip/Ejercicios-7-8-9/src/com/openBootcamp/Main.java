package com.openBootcamp;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;

public class Main {




    public static void main(String[] args) {


        String name = "Me llamo Alejandra Naranjo Salinas";
        StringBuilder nameB = new StringBuilder(name);
        name = nameB.reverse().toString();
        System.out.println(name);


        int[] arrayTest = {1, 2, 3, 4, 5};
        for (int num : arrayTest) {
            System.out.println(num);
        }

        int[][] arrayBi = {
                {1, 2, 3, 4, 5},
                {6, 7, 8, 9, 10}
        };
        for (int i = 0; i < arrayBi.length; i++) {
            for (int j = 0; j < arrayBi[i].length; j++) {
                System.out.println("Posicion: [" + i + "][" + j + "] y contiene el valor " + arrayBi[i][j]);
            }

        }

        Vector<String> vector = new Vector<>();
        vector.add("Hola,");
        vector.add("es");
        vector.add("hora");
        vector.add("de");
        vector.add("programar");

        System.out.println(vector);

        vector.remove(1);
        vector.remove(1);

        System.out.println(vector);

        /*Al usar un vector con una capacidad determinada by default, en este caso de 1000 elementos
        tan pronto como alcancemos esta capacidad, el vector duplicara automaticamente su capacidad
        lo que implia un gran costo de programacion, ya que hace una copia en memoria de los 1000
        elementos ya alcanzados y separa el espacio de 1000 mas, para un total de 2000; mas los 1000
        preexistentes.
         */

        ArrayList<String> apellidos = new ArrayList<>();
        apellidos.add("Naranjo");
        apellidos.add("Salinas");
        apellidos.add("Cardona");
        apellidos.add("Mera");

        LinkedList<String> linkedApellidos = new LinkedList<>(apellidos);

        for (String apellido : apellidos) {
            System.out.println("Estoy en un arrayList" + " " + apellido);
        }
        for (String apellidoLinked : linkedApellidos) {
            System.out.println("Estoy en un linkedList" + " " + apellidoLinked);
        }

        ArrayList<Integer> test = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            test.add(i + 1);

        }
        System.out.println(test);

        for (int i = 0; i < test.size(); i++) {

            if (test.get(i) % 2 == 0) {
                test.remove(i);
            }
        }
        System.out.println(test);

    }

}
