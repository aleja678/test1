package com.openBootcamp;

import java.io.*;

public class Fichero {

    public static void main(String[] args) {

        try {
            InputStream ficheroOrigen= new FileInputStream("C:\\prueba\\fichero_prueba.txt");
            byte []datos = ficheroOrigen.readAllBytes();

            PrintStream ficheroCopia = new PrintStream("fichero_copia.txt");
            ficheroCopia.write(datos);
            ficheroOrigen.close();
            ficheroCopia.close();

        } catch (Exception e) {
            System.out.println("Excepcion generada"+ e.getMessage());
        }

    }

}


